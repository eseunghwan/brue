# -*- coding: utf-8 -*-

from brue import brueStore

store = brueStore(
    count_num = 1
)
