# -*- coding: utf-8 -*-
from brue import BrueDOM
from App import App

BrueDOM.mount(App, "app-main")
